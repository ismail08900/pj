from interface import lancer_app

lancer_app()
